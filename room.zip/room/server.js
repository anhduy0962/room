const express = require('express');
const app = express();
const path = require('path');
const router = express.Router();
var http = require('http').Server(app);
var io = require('socket.io')(http);
app.use(express.static('public'))
//app.use(express.static(__dirname + 'public'));
router.get('/',function(req,res){
  res.sendFile(path.join(__dirname + '/webrtcB_fixed.html'));
  //__dirname : It will resolve to your project folder.
});

var roomno = 1;
io.on('connection', function(socket) {
   
   //Increase roomno 2 clients are present in a room.
   if(io.nsps['/'].adapter.rooms["room-"+roomno] && io.nsps['/'].adapter.rooms["room-"+roomno].length > 1) roomno++;
   socket.join("room-"+roomno);

   //Send this event to everyone in the room.
   io.sockets.in("room-"+roomno).emit('connectToRoom', "You are in room no. "+roomno);
})
//router.get('/about',function(req,res){
//  res.sendFile(path.join(__dirname+'/common/images/sitename.png'));
//});

//router.get('/sitemap',function(req,res){
//  res.sendFile(path.join(__dirname+'/common/css/style.css'));
//});

//add the router
//app.use(express.static(__dirname + '/common/images'));
//Store all HTML files in view folder.
//app.use(express.static(__dirname + '/common/css'));
//Store all JS and CSS in Scripts folder.

app.use('/', router);
app.listen(process.env.port || 3000);

console.log('Running at Port 3000');

