var dns = require('dns'); 
var process = require('child_process'); 
var port1 = 9001;
var io = require('socket.io').listen(port1); 
var ipAddress = ''; 
var net = require('net');
var client = new net.Socket(); 
client.setEncoding('utf8'); 
var socketClients = {}; 
var roomno = 1; //var room = 1;

console.log(" version 1.1.5 "); 
console.log((new Date()) + " Server is listening on port " + port1);

//var nsp = io.of('/my-namespace'); 
//nsp.on('connection', function(socket) {
 io.sockets.on('connection', function(socket) {
//   console.log('someone connected');
 console.log((new Date()) + "Accept!!\n");
//   io.emit('hi', 'Hello everyone!');
//});
//   console.log( "Current room is: " + room)
//   socket.on('enter', function() {
//      socket.join(room);
//      console.log('id=' + socket.id + ' enter room=' + room);
//    });
   
  //Increase roomno 2 clients are present in a room.
  if(io.nsps['/'].adapter.rooms["room-"+roomno] && io.nsps['/'].adapter.rooms["room-"+roomno].length > 1) roomno++;
//  if (roomno==1){
  socketClients[socket.id] = socket;
//  }
//  else {
//  console.log("room " + roomno-1 + "is full");
//  roomno = 1;
//  }
  console.log("client Id"+ socket.id);
  for (var key in socketClients) {

      console.log(key);
    }

   //Increase roomno 2 clients are present in a room.
//   if(io.nsps['/'].adapter.rooms["room-"+roomno] && io.nsps['/'].adapter.rooms["room-"+roomno].length > 1) roomno++;
   socket.join("room-"+roomno);

   //Send this event to everyone in the room.
//   io.sockets.in("room-"+roomno).emit('connectToRoom', "You are in room no. "+roomno);
    console.log(" You are in room " + roomno);
//  socket.join('textRoom');
//  socket.on('joined', function(textRoom){
//    socket.broadcast.emit('joined', textRoom);
//    console.log((new Date()) + " Server is listening on room " + textRoom); 
//  });
  
  socket.on('message', function(message) {
     socket.broadcast.emit('message', message);
  });
 // if(roomno == 1){
  socket.on('ipSend', function(data) {
    console.log(socket.request.connection.remoteAddress);
    socket.broadcast.emit('ipSend',socket.request.connection.remoteAddress);
    console.log("ipSend" + 'ipSend');
  });
 // }
 // else {
 // console.log("room " + roomno-- + "is full");
 // roomno = 1;
 // }

  socket.on('ipRes', function(bl) {
    console.log(bl);
    socket.broadcast.emit('ipRes', bl);
  });
  
  socket.on('ipSet', function(data) {
    console.log('ipSet:'+data);
    ipAddress = data;
  });
  
  socket.on('ipGet', function(data) {
    console.log('ipGet:'+ipAddress);
    io.to(socket.id).emit('ipGet',ipAddress);
  });
  
  socket.on('androidServerCheck', function(url) {
    console.log('urlCheck:'+url);
    
    client.connect(9002, url, function() {
	  console.log('Connected'+client.id);
	  client.write(url);
	  io.to(socket.id).emit('androidServerCheck',true);
    });
    
    client.on('data', function(data) {
	  console.log('Received: ' + data);
	  client.destroy(); // kill client after server's response
    });

    client.on('close', function() {
	  console.log('Connection closed'+client.id);
	  client = new net.Socket();
    });
    
    client.on('error', function(err){
      console.log("Error: "+err.message);
      io.to(socket.id).emit('androidServerCheck',false);
      client.destroy();
    });
  });
  
  socket.on('androidConnect', function(bl) {
    console.log('androidConnect:'+bl);
    socket.broadcast.emit('androidConnect', bl);
  });
  
  //fqdn��IP�A�h���X�ɕϊ��ł��邩
  socket.on('fqdnCheck', function(data) {
    
    function fqdnEmit(ip) {
      //io.to(socket.id).emit('fqdnCheck','192.168.11.40');
      io.to(socket.id).emit('fqdnCheck',ip);
    }
    
    //2018/08/11 �ύX �쑺
    //FQDN������nslookup����ping�ɕύX
    //setTimeout(function(){checkLookup(data,true,fqdnEmit);},5000);
    //checkLookup(data,false,fqdnEmit);
    checkPing(data,fqdnEmit);
  });

// ---- multi room ----
 
// }
// else {
//  console.log((new Date()) +"room" + (roomno-1) + " is full");
//  }
  socket.on('disconnected', function(bl) {
    console.log('hangup:' + socket.id);
    socket.broadcast.emit('disconnected',bl);

    for (var key in socketClients) {
      console.log(key);
      delete socketClients[key];
    }
    //reset roomno to 1
    roomno = 1;
    console.log("reset  roomno to :" + roomno)
  });
});
// } of if (roomno ==1)


var blLookup = false;

function checkLookup(data,blTimeOut,callback) {
  console.log('fqdnCheck:' + data);
  console.log('blTimeOut:' + blTimeOut);
  
  if(blTimeOut == false)
  {
    dns.lookup(data, function onLookup(err, address, family) {
      blLookup = true;
      if (err) {
        console.log('ip:null');
        callback(null);
      }
      else
      {
        console.log('ip:', address);
        callback(address);
      }
    });
  }
  else
  {
    if(blLookup)
    {
      blLookup = false;
    }
    else
    {
      callback(null);
    }
  }
}

//2018/08/11 �ǉ� �쑺
function checkPing(data,callback)
{
  console.log('fqdnCheck:' + data);
  
  var exec = process.exec('ping -c 1 -n ' + data,(error,stdout,stderr) => {
    if(error)
    {
      console.log('error:' + stderr);
      callback(null);
    }
    else
    {
      console.log('stdout:' + stdout);

      var start = stdout.indexOf('(', 0) + 1;
      var end = stdout.indexOf(')', start);
      
      console.log('start:' + start);
      console.log('end:' + end);
      
      var address = stdout.slice(start,end);
      
      console.log('address:' + address);
      
      callback(address);
    }
  });
}

